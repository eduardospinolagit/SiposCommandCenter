@echo off
chcp 65001 >nul
title SLAC WhatsApp Server

echo.
echo  ╔══════════════════════════════════════╗
echo  ║      SLAC WhatsApp Server v2         ║
echo  ╚══════════════════════════════════════╝
echo.

:: Muda para o diretório onde o .bat está (necessário ao executar via duplo clique)
cd /d "%~dp0"

:: Verifica se Node.js está instalado
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Node.js nao encontrado no seu computador.
    echo.
    echo  Vamos instalar agora. Siga os passos:
    echo   1. Baixe e instale o Node.js pelo link que vai abrir
    echo   2. Clique em "Next" em todas as telas
    echo   3. Apos instalar, FECHE esta janela e abra o INICIAR.bat novamente
    echo.
    start https://nodejs.org/dist/v20.19.1/node-v20.19.1-x64.msi
    pause
    exit
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo  [OK] Node.js %NODE_VER% encontrado.
echo.

:: Usa package-dist.json como package.json na primeira vez
if not exist "package.json" (
    copy package-dist.json package.json >nul
)

:: Instala dependências se necessário
if not exist "node_modules\" (
    echo  [->] Instalando dependencias pela primeira vez...
    echo      (isso leva ~1 minuto, so acontece uma vez)
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo  [!] Erro ao instalar dependencias. Verifique sua conexao com a internet.
        pause
        exit
    )
    echo.
    echo  [OK] Dependencias instaladas!
    echo.
)

:: Inicia o servidor
echo  [->] Iniciando servidor WhatsApp...
echo  [i]  Mantenha esta janela aberta enquanto usar o SlacZap.
echo  [i]  Para parar: feche esta janela ou pressione Ctrl+C
echo.
echo ──────────────────────────────────────────
echo.

node src-js\index.js

echo.
echo  Servidor encerrado.
pause
