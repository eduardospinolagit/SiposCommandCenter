import express       from 'express'
import cors          from 'cors'
import fs            from 'fs'
import path          from 'path'
import { createClient } from '@supabase/supabase-js'
import { WASession } from './wa-session.js'

const PORT        = parseInt(process.env.PORT ?? '3001', 10)
const TOKEN_CACHE = path.join(process.cwd(), 'token_cache.json')
const SB_URL      = 'https://jqmnmudfxxdcjfradvcj.supabase.co'
const SB_ANON     = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpxbW5tdWRmeHhkY2pmcmFkdmNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwNDAxNTMsImV4cCI6MjA4OTYxNjE1M30.LKZz_djPhIc_PvdLxAAhLaV-BZxX70nGup-qODIDEF4'

const sbAnon = createClient(SB_URL, SB_ANON)
function getDb(token) {
  if (!token) return sbAnon
  return createClient(SB_URL, SB_ANON, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth:   { persistSession: false, autoRefreshToken: false },
  })
}

// ─── Estado ──────────────────────────────────────────────────

let currentToken  = null
let currentUserId = null
let pendingMsgs   = []

try {
  const saved = JSON.parse(fs.readFileSync(TOKEN_CACHE, 'utf-8'))
  if (saved?.token && saved?.exp && saved.exp > Math.floor(Date.now() / 1000)) {
    currentToken  = saved.token
    currentUserId = saved.userId
    console.log('🔑 JWT restaurado — user:', currentUserId?.slice(0, 8) + '...')
  } else {
    console.log('⚠️  Cache JWT expirado — aguardando SlacZap enviar token')
  }
} catch {}

// ─── Sessão WhatsApp ─────────────────────────────────────────

const wa = new WASession()

// ─── Salvar mensagem ─────────────────────────────────────────

async function salvarMensagem(msg) {
  let jid = msg.key.remoteJid ?? ''
  if (!jid || jid.endsWith('@g.us') || jid.endsWith('@broadcast')) return

  if (jid.endsWith('@lid')) {
    const resolved = await wa.resolveLidJid(jid)
    if (resolved === jid) { console.warn(`⚠️  LID não resolvido: ${jid}`); return }
    jid = resolved
  }

  const from = jid.replace('@s.whatsapp.net', '').replace(/\D/g, '')
  if (!from) return

  const text =
    msg.message?.conversation                            ??
    msg.message?.extendedTextMessage?.text              ??
    msg.message?.imageMessage?.caption                  ??
    msg.message?.videoMessage?.caption                  ??
    (msg.message?.audioMessage    ? '[Áudio]'           : null) ??
    (msg.message?.imageMessage    ? '[Imagem]'          : null) ??
    (msg.message?.videoMessage    ? '[Vídeo]'           : null) ??
    (msg.message?.documentMessage ? `[Documento: ${msg.message.documentMessage.fileName ?? 'arquivo'}]` : null) ??
    (msg.message?.stickerMessage  ? '[Sticker]'         : null)
  if (!text) return

  const direcao = msg.key.fromMe ? 'enviado' : 'recebido'
  const data    = msg.messageTimestamp
    ? new Date(Number(msg.messageTimestamp) * 1000).toISOString()
    : new Date().toISOString()
  const tail = from.replace(/^55/, '').slice(-8)
  if (tail.length < 7) return

  const ctxInfo = msg.message?.extendedTextMessage?.contextInfo
  let quoted = null
  if (ctxInfo?.quotedMessage && ctxInfo?.stanzaId) {
    const qText = ctxInfo.quotedMessage?.conversation ?? ctxInfo.quotedMessage?.extendedTextMessage?.text ?? null
    quoted = { id: 'wa_' + ctxInfo.stanzaId, mensagem: qText, direcao: ctxInfo.participant ? 'recebido' : 'enviado' }
  }

  const db = getDb(currentToken)
  const { data: leadRows } = await db.from('leads').select('id, user_id, telefone').ilike('telefone', `%${tail}%`)

  let lead = null, bestOverlap = 0
  for (const l of (leadRows ?? [])) {
    const lDigits = (l.telefone ?? '').replace(/\D/g, '')
    const overlap = lDigits.length > 0 && from.endsWith(lDigits.slice(-10)) ? lDigits.length : 0
    if (overlap > bestOverlap) { bestOverlap = overlap; lead = l }
  }

  if (msg.key.id) wa.setCachedMsg('wa_' + msg.key.id, msg)

  if (lead && bestOverlap > 0) {
    await db.from('conversas').upsert({
      id: 'wa_' + msg.key.id, user_id: lead.user_id, lead_id: lead.id,
      canal: 'whatsapp', direcao, mensagem: text, data,
      status: direcao === 'enviado' ? 'sent' : 'received', quoted,
    }, { onConflict: 'id', ignoreDuplicates: true })
  } else if (currentUserId) {
    await db.from('conversas').upsert({
      id: 'wa_' + msg.key.id, user_id: currentUserId, lead_id: null,
      telefone: from.replace(/^55/, ''), canal: 'whatsapp', direcao, mensagem: text, data,
      status: direcao === 'enviado' ? 'sent' : 'received', quoted,
    }, { onConflict: 'id', ignoreDuplicates: true })
  } else {
    console.warn(`⚠️  Mensagem de ${from} ignorada — sem token`)
  }
}

// ─── Eventos ─────────────────────────────────────────────────

wa.on('message', async (msg, type) => {
  if (type === 'notify') {
    const text = msg.message?.conversation ?? msg.message?.extendedTextMessage?.text ?? ''
    console.log(`📩 ${msg.key.fromMe ? '→' : '←'} ${msg.key.remoteJid}: ${text.slice(0, 60)}`)
  }
  if (!currentToken) { pendingMsgs.push(msg); if (pendingMsgs.length > 500) pendingMsgs.shift(); return }
  try { await salvarMensagem(msg) } catch (e) { console.error('Erro salvar:', e.message) }
})

wa.on('history', async (msgs) => {
  if (!currentToken) {
    pendingMsgs.push(...msgs)
    if (pendingMsgs.length > 500) pendingMsgs.splice(0, pendingMsgs.length - 500)
    console.log(`⏳ ${msgs.length} msgs históricas em buffer (total: ${pendingMsgs.length})`)
    return
  }
  let saved = 0
  for (const msg of msgs) { try { await salvarMensagem(msg); saved++ } catch {} }
  console.log(`✅ Histórico: ${saved}/${msgs.length} salvas`)
})

async function flushPendingMsgs() {
  if (!pendingMsgs.length) return
  const toProcess = pendingMsgs.splice(0)
  console.log(`📬 Processando ${toProcess.length} msgs do buffer...`)
  let saved = 0
  for (const msg of toProcess) { try { await salvarMensagem(msg); saved++ } catch {} }
  console.log(`✅ Buffer: ${saved}/${toProcess.length} msgs salvas`)
}

async function salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem }) {
  if (!user_id) return
  const row = {
    id: 'wa_out_' + Date.now() + '_' + Math.random().toString(36).slice(2),
    user_id, lead_id: lead_id ?? null, canal: 'whatsapp', direcao: 'enviado',
    mensagem, data: new Date().toISOString(), status: 'sent',
  }
  if (!lead_id && telefone) row.telefone = String(telefone).replace(/\D/g, '').replace(/^55/, '')
  const { error } = await getDb(currentToken).from('conversas').insert(row)
  if (error) console.error('❌ Erro ao salvar mídia:', error.message)
}

// ─── Express ─────────────────────────────────────────────────

const app = express()
app.use(cors())
app.use(express.json({ limit: '20mb' }))

app.get('/status', (_req, res) => res.json(wa.getStatus()))

app.get('/bridge-token', (_req, res) => {
  if (!currentToken) return res.status(401).json({ error: 'token não disponível' })
  res.json({ token: currentToken, userId: currentUserId })
})

app.post('/set-token', async (req, res) => {
  const { token } = req.body ?? {}
  if (token) {
    try {
      const payload  = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString())
      currentToken   = token
      currentUserId  = payload.sub ?? null
      try { fs.writeFileSync(TOKEN_CACHE, JSON.stringify({ token, userId: currentUserId, exp: payload.exp })) } catch {}
      console.log('🔑 Token atualizado — user:', currentUserId?.slice(0, 8) + '...')
      flushPendingMsgs().catch(console.error)
    } catch (e) { console.error('❌ Erro ao parsear token:', e.message) }
  }
  res.json({ ok: true })
})

app.post('/sync-history', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  if (!currentToken)     return res.status(401).json({ error: 'Token não disponível' })
  res.json({ ok: true })
  ;(async () => {
    try {
      const { data: leadsData } = await getDb(currentToken).from('leads').select('id, user_id, telefone').not('telefone', 'is', null).limit(100)
      if (!leadsData?.length) return
      let total = 0
      for (const lead of leadsData) {
        try {
          const jid  = await wa.resolveJid(lead.telefone)
          const msgs = await wa.loadMessages(jid, 30)
          for (const msg of msgs) { if (!msg.message) continue; await salvarMensagem(msg); total++ }
        } catch {}
      }
      console.log(`✅ Sync: ${total} mensagens processadas`)
    } catch (e) { console.error('❌ Sync falhou:', e.message) }
  })()
})

app.post('/reconnect', (_req, res) => {
  res.json({ ok: true })
  wa.disconnect()
  setTimeout(() => wa.connect().catch(console.error), 1_500)
})

app.post('/disconnect', (_req, res) => {
  res.json({ ok: true })
  wa.logoutAndReset().catch(console.error)
})

app.post('/send-text', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  const { telefone, mensagem, lead_id, user_id, quoted_id, contato_nome } = req.body ?? {}
  if (!telefone || !mensagem) return res.status(400).json({ error: 'telefone e mensagem obrigatórios' })
  try {
    const jid = await wa.resolveJid(telefone)
    let quotedMsg, quotedData = null
    if (quoted_id) {
      const { data: orig } = await getDb(currentToken).from('conversas').select('mensagem, direcao').eq('id', quoted_id).maybeSingle()
      if (orig) {
        const waId = quoted_id.startsWith('wa_') ? quoted_id.slice(3) : quoted_id
        const raw  = wa.getCachedMsg(quoted_id)
        quotedMsg  = raw ?? { key: { remoteJid: jid, fromMe: orig.direcao === 'enviado', id: waId }, message: { conversation: orig.mensagem ?? '' } }
        quotedData = { id: quoted_id, mensagem: orig.mensagem, direcao: orig.direcao }
      }
    }
    const sentId = await wa.sendText(jid, mensagem, quotedMsg)
    const realId = sentId ? 'wa_' + sentId : 'wa_out_' + Date.now() + '_' + Math.random().toString(36).slice(2)
    if (user_id) {
      const row = { id: realId, user_id, lead_id: lead_id ?? null, canal: 'whatsapp', direcao: 'enviado', mensagem, data: new Date().toISOString(), status: 'sent', quoted: quotedData }
      if (!lead_id && telefone) { row.telefone = String(telefone).replace(/\D/g, '').replace(/^55/, ''); if (contato_nome) row.contato_nome = contato_nome }
      await getDb(currentToken).from('conversas').insert(row)
    }
    res.json({ ok: true })
  } catch (e) { console.error('Erro send-text:', e.message); res.status(500).json({ error: e.message }) }
})

app.post('/send-image', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  const { telefone, imagem, caption, lead_id, user_id } = req.body ?? {}
  if (!telefone || !imagem) return res.status(400).json({ error: 'telefone e imagem obrigatórios' })
  try {
    const jid = await wa.resolveJid(telefone)
    await wa.sendImage(jid, Buffer.from(imagem.replace(/^data:[^;]+;base64,/, ''), 'base64'), caption)
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: caption || '[Imagem]' })
    res.json({ ok: true })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

app.post('/send-video', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  const { telefone, video, caption, lead_id, user_id } = req.body ?? {}
  if (!telefone || !video) return res.status(400).json({ error: 'telefone e video obrigatórios' })
  try {
    const jid = await wa.resolveJid(telefone)
    await wa.sendVideo(jid, Buffer.from(video.replace(/^data:[^;]+;base64,/, ''), 'base64'), caption)
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: caption || '[Vídeo]' })
    res.json({ ok: true })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

app.post('/send-audio', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  const { telefone, audio, lead_id, user_id } = req.body ?? {}
  if (!telefone || !audio) return res.status(400).json({ error: 'telefone e audio obrigatórios' })
  try {
    const jid = await wa.resolveJid(telefone)
    await wa.sendAudio(jid, Buffer.from(audio.replace(/^data:[^;]+;base64,/, ''), 'base64'))
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: '[Áudio]' })
    res.json({ ok: true })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

app.post('/send-document', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' })
  const { telefone, documento, nome, mimetype, lead_id, user_id } = req.body ?? {}
  if (!telefone || !documento) return res.status(400).json({ error: 'telefone e documento obrigatórios' })
  try {
    const jid = await wa.resolveJid(telefone)
    await wa.sendDocument(jid, Buffer.from(documento.replace(/^data:[^;]+;base64,/, ''), 'base64'), nome ?? 'arquivo', mimetype ?? 'application/octet-stream')
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: `[Documento: ${nome ?? 'arquivo'}]` })
    res.json({ ok: true })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

app.get('/debug', async (_req, res) => {
  const { data: leads } = await getDb(currentToken).from('leads').select('id').limit(5)
  const { data: convs }  = await getDb(currentToken).from('conversas').select('id').eq('canal', 'whatsapp').limit(5)
  res.json({ ...wa.getStatus(), hasToken: !!currentToken, userId: currentUserId, leadsCount: leads?.length ?? 0, conversasCount: convs?.length ?? 0 })
})

// ─── Start ───────────────────────────────────────────────────

const server = app.listen(PORT, () => {
  console.log(`\n🚀 SLAC Server v2 rodando em http://localhost:${PORT}`)
  console.log('📱 Iniciando conexão WhatsApp...\n')
})

process.on('SIGINT',  () => { server.close(); process.exit(0) })
process.on('SIGTERM', () => { server.close(); process.exit(0) })

wa.connect().catch(console.error)
