import path         from 'path'
import fs           from 'fs'
import { EventEmitter } from 'events'
import QRCode       from 'qrcode'
import qrTerminal   from 'qrcode-terminal'

const AUTH_DIR      = path.join(process.cwd(), 'auth_info')
const MSG_CACHE_MAX = 300

export class WASession extends EventEmitter {
  constructor() {
    super()
    this.socket        = null
    this.status        = 'disconnected'
    this.qrRaw         = null
    this.qrImages      = null
    this.msgCache      = new Map()
    this.autoReconnect = false
    this.retryQueue    = []
    this.lidToJid      = new Map()
    this._loadRetryQueue()
    this._loadLidCache()
  }

  async connect() {
    if (this.socket) {
      try { this.socket.end?.(undefined) } catch {}
      this.socket = null
    }
    this.autoReconnect = true
    this.status = 'connecting'

    const {
      default: makeWASocket,
      useMultiFileAuthState,
      DisconnectReason,
      fetchLatestBaileysVersion,
      Browsers,
    } = await import('@whiskeysockets/baileys')

    if (!fs.existsSync(AUTH_DIR)) fs.mkdirSync(AUTH_DIR, { recursive: true })

    const { state: authState, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
    const { version }                     = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      version,
      auth:                           authState,
      printQRInTerminal:              false,
      logger:                         this._silentLogger(),
      browser:                        Browsers.ubuntu('Chrome'),
      generateHighQualityLinkPreview: false,
      markOnlineOnConnect:            false,
      syncFullHistory:                false,
      fireInitQueries:                true,
      connectTimeoutMs:               60_000,
      keepAliveIntervalMs:            25_000,
      retryRequestDelayMs:            2_000,
      getMessage:                     async () => ({ conversation: '' }),
    })

    this.socket = sock

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update

      if (qr) {
        this.status   = 'qr_pending'
        this.qrRaw    = qr
        this.qrImages = null
        qrTerminal.generate(qr, { small: true })
        console.log('\n🔲 QR Code gerado — acesse http://localhost:3001\n')
        Promise.all([
          QRCode.toDataURL(qr, { width: 256, margin: 1, color: { dark: '#22c55e', light: '#0f0f0f' } }),
          QRCode.toDataURL(qr, { width: 256, margin: 1, color: { dark: '#111111', light: '#ffffff' } }),
        ]).then(([dark, light]) => { this.qrImages = { dark, light } }).catch(() => {})
        this.emit('qr', qr)
      }

      if (connection === 'open') {
        this.status   = 'connected'
        this.qrRaw    = null
        this.qrImages = null
        console.log('✅ WhatsApp conectado!')
        this.emit('connected')
        setTimeout(() => this._flushRetryQueue().catch(console.error), 2_000)
      }

      if (connection === 'close') {
        const code        = lastDisconnect?.error?.output?.statusCode
        const isLoggedOut = code === DisconnectReason.loggedOut
        const isReplaced  = code === 440
        this.status = 'disconnected'
        this.socket = null
        console.log(`⚠️  Conexão fechada (código ${code}).`)
        this.emit('disconnected', code)

        if (!this.autoReconnect) return

        if (isLoggedOut || isReplaced) {
          this.autoReconnect = false
          console.log(`🔴 Sessão ${isLoggedOut ? 'encerrada (logout)' : 'substituída'} — aguardando nova conexão.`)
          if (isLoggedOut) try { fs.rmSync(AUTH_DIR, { recursive: true, force: true }) } catch {}
          setTimeout(() => this.connect().catch(console.error), 1_500)
        } else {
          const delay = code === 408 ? 3_000 : 5_000
          console.log(`🔄 Reconectando em ${delay / 1000}s...`)
          setTimeout(() => this.connect().catch(console.error), delay)
        }
      }
    })

    sock.ev.on('creds.update', saveCreds)

    const indexContacts = (contacts) => {
      let added = 0
      for (const c of contacts) {
        if (c.id && c.lid) {
          this.lidToJid.set(c.lid, c.id)
          this.lidToJid.set(c.lid.split('@')[0], c.id)
          added++
        }
      }
      if (added > 0) console.log(`📒 ${added} contatos LID indexados (total: ${this.lidToJid.size})`)
    }
    sock.ev.on('contacts.upsert', indexContacts)
    sock.ev.on('contacts.update', indexContacts)

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify' && type !== 'append') return
      for (const msg of messages) {
        if (!msg.message) continue
        this.emit('message', msg, type)
      }
    })

    sock.ev.on('messaging-history.set', ({ messages: histMsgs }) => {
      const relevant = histMsgs.filter(m => m.message)
      console.log(`📚 Histórico: ${relevant.length} mensagens`)
      this.emit('history', relevant)
    })
  }

  disconnect() {
    this.autoReconnect = false
    try { this.socket?.end?.(undefined) } catch {}
    this.socket = null
    this.status = 'disconnected'
    this.qrRaw  = null
    this.qrImages = null
    console.log('🔌 Desconectado manualmente')
  }

  async logoutAndReset() {
    this.autoReconnect = false
    try { await this.socket?.logout() } catch {}
    try { this.socket?.end?.(undefined) } catch {}
    this.socket = null
    this.status = 'disconnected'
    this.qrRaw  = null
    this.qrImages = null
    try { fs.rmSync(AUTH_DIR, { recursive: true, force: true }) } catch {}
    console.log('🔴 Sessão encerrada. Gerando novo QR...')
    setTimeout(() => this.connect().catch(console.error), 1_500)
  }

  async resolveJid(telefone) {
    let tel = String(telefone).replace(/\D/g, '')
    if (!tel.startsWith('55')) tel = '55' + tel
    const variants = new Set([tel])
    if (tel.length === 13) variants.add(tel.slice(0, 4) + tel.slice(5))
    else if (tel.length === 12) variants.add(tel.slice(0, 4) + '9' + tel.slice(4))
    if (!this.socket) return tel + '@s.whatsapp.net'
    for (const v of variants) {
      const jid = v + '@s.whatsapp.net'
      try {
        const [result] = await this.socket.onWhatsApp(jid)
        if (result?.exists) {
          if (v !== tel) console.log(`📱 JID ajustado: ${tel} → ${v}`)
          return result.jid || jid
        }
      } catch {}
    }
    return tel + '@s.whatsapp.net'
  }

  async resolveLidJid(jid) {
    if (!jid.endsWith('@lid')) return jid
    const cached = this.lidToJid.get(jid) || this.lidToJid.get(jid.split('@')[0])
    if (cached) return cached
    if (this.socket) {
      try {
        const results = await this.socket.onWhatsApp(jid)
        const resolved = results?.[0]
        if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
          this.lidToJid.set(jid, resolved.jid)
          return resolved.jid
        }
      } catch {}
    }
    return jid
  }

  async sendText(jid, text, quotedMsg) {
    this._assertConnected()
    const opts = quotedMsg ? { quoted: quotedMsg } : {}
    const sent = await this.socket.sendMessage(jid, { text }, opts)
    return sent?.key?.id ?? ''
  }

  async sendImage(jid, buffer, caption = '') {
    this._assertConnected()
    await this.socket.sendMessage(jid, { image: buffer, caption })
  }

  async sendVideo(jid, buffer, caption = '') {
    this._assertConnected()
    await this.socket.sendMessage(jid, { video: buffer, caption })
  }

  async sendAudio(jid, buffer) {
    this._assertConnected()
    await this.socket.sendMessage(jid, { audio: buffer, ptt: true, mimetype: 'audio/ogg; codecs=opus' })
  }

  async sendDocument(jid, buffer, fileName, mimetype) {
    this._assertConnected()
    await this.socket.sendMessage(jid, { document: buffer, fileName, mimetype })
  }

  async loadMessages(jid, count = 30) {
    if (!this.socket) return []
    try {
      const result = await this.socket.loadMessages(jid, count, undefined)
      return result?.messages ?? []
    } catch { return [] }
  }

  getStatus() {
    return {
      connected:    this.status === 'connected',
      hasQr:        this.status === 'qr_pending' && !!this.qrRaw,
      qrImage:      this.qrImages?.dark  ?? null,
      qrImageLight: this.qrImages?.light ?? null,
    }
  }

  isConnected() { return this.status === 'connected' && !!this.socket }

  getCachedMsg(id)         { return this.msgCache.get(id) }
  setCachedMsg(id, msg)    {
    if (this.msgCache.size >= MSG_CACHE_MAX) {
      const first = this.msgCache.keys().next().value
      if (first !== undefined) this.msgCache.delete(first)
    }
    this.msgCache.set(id, msg)
  }

  async _flushRetryQueue() {
    if (!this.retryQueue.length) return
    const queue = [...this.retryQueue]
    this.retryQueue = []
    this._saveRetryQueue()
    for (const item of queue) {
      try {
        const jid = item.waJid ?? await this.resolveJid(item.phone)
        await this.sendText(jid, item.text)
      } catch { this.retryQueue.push(item) }
    }
    if (this.retryQueue.length) this._saveRetryQueue()
  }

  _saveRetryQueue() {
    try {
      if (!fs.existsSync(AUTH_DIR)) return
      fs.writeFileSync(path.join(AUTH_DIR, 'retry_queue.json'), JSON.stringify(this.retryQueue))
    } catch {}
  }

  _loadRetryQueue() {
    try {
      const file = path.join(AUTH_DIR, 'retry_queue.json')
      if (fs.existsSync(file)) {
        const data = JSON.parse(fs.readFileSync(file, 'utf-8'))
        if (Array.isArray(data) && data.length > 0) this.retryQueue = data
      }
    } catch {}
  }

  _loadLidCache() {
    try {
      if (!fs.existsSync(AUTH_DIR)) return
      const files = fs.readdirSync(AUTH_DIR).filter(f => f.startsWith('lid-mapping-') && f.endsWith('_reverse.json'))
      for (const f of files) {
        try {
          const lid   = f.replace('lid-mapping-', '').replace('_reverse.json', '')
          const phone = JSON.parse(fs.readFileSync(path.join(AUTH_DIR, f), 'utf-8'))
          if (phone && typeof phone === 'string') {
            this.lidToJid.set(lid + '@lid', phone + '@s.whatsapp.net')
            this.lidToJid.set(lid, phone + '@s.whatsapp.net')
          }
        } catch {}
      }
      if (this.lidToJid.size > 0) console.log(`📒 ${this.lidToJid.size} contatos LID carregados`)
    } catch {}
  }

  _assertConnected() {
    if (!this.isConnected()) throw new Error('WhatsApp não está conectado')
  }

  _silentLogger() {
    const noop = () => {}
    const stub = { level: 'silent', trace: noop, debug: noop, info: noop, warn: noop, error: noop, fatal: noop }
    stub.child = () => this._silentLogger()
    return stub
  }
}
